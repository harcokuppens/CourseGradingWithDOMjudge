// HelloWorldPrinter.java
public class HelloWorldPrinter {
    public void printMessage() {
        System.out.println("Hello world!");
    }
}
