#include <iostream>
#include <vector>
#include <queue>
using namespace std;

/* sample input
4 5 
0 1 2 3
0 5 10 15
3 2 1 4
10 20 50 60
2 4 3 1
15 17 20 25
1 3 4 2
6 9 25 35



Merc (0): (0,5,1) -----5----------
Spor(1): (5,10,2), (50,60,4) (6,9,3) ---------5/10/3-------------
CS (2): (15,17,4), (10,15,3), (20,50,1) ----------2/5/30------------
Walk (3): (10,20,2), (20,25,1), (9,25,4) ----------10/5/16------------
Home (4): (17,20,3),(25,35,2) ------------------3/10-----------------------

*/




struct ride {
    int start;
    int end;
    int stop;
};


vector<vector<ride>> g;
vector<bool> visited;
vector<int> best_time;    // best times to reach stops
vector<int> dep_time;

/* class Compare {
public:
    bool operator()(int u, int v) {
        return best_time[u] > best_time[v];
    }
};*/

class heap {
private:
    // data represents the stops
    vector<int> data;

    // If best_time[data[a]] is smaller than best_time[data[b]], a has higher priority than b.
    bool higher_priority(int a, int b) {
        // return data[a] < data[b];
        return best_time[data[a]] < best_time[data[b]];
    }

    void swap(int i, int j) {
        int tmp = data[i];
        data[i] = data[j];
        data[j] = tmp;
    }

public:
    heap() {
        data = {};
    }

    bool empty() {
        return data.empty();
    }

    // returns the root of the heap
    int top() {
        if (!data.empty()) {
            return data[0];
        }
        return -1;
    }

    void push(int el) {
        data.push_back(el);
        // j is an index of a newly added element
        int j = data.size() - 1;
        // i is an index of j's parent
        int i = (j-1) / 2;
        
        while (i >= 0 && higher_priority(j, i)) {
            swap(i, j);
            j = i;
            i = (i - 1)/2;
        }
    }

    // Removes the highest-priority element (the root of the heap) and restores the heap after the root is removed.
    void pop() {
        if (data.empty()) return;
        swap(0, data.size()-1);
        data.erase(data.end()-1);
        int i = 0;
        bool f = true;
        while (2 * i + 1 < data.size() && f) {
            f = false;
            int c1 = 2 * i + 1;        //left child index
            int c2 = 2 * i + 2;        //right child index
            if (c2 < data.size() && higher_priority(c2, i) && higher_priority(c2, c1)) {
                swap(c2, i);           // Swap with the right child if it has the highest priority
                i = c2;
                f = true;
            } else if (higher_priority(c1, i)) {
                swap(c1, i);           // Otherwise, swap with the left child if it has the highest priority
                i = c1;
                f = true;
            }
        }
    }

    int find (int el) {
        for (int i = 0; i < data.size(); i++) {
            if (data[i] == el) {
                return i;
            }
        }
        return -1;
    }

    void increase_priority (int el) {
        int j = find(el);
        if (j == -1) return;
        int i = (j - 1)/2;  // i is a parent node of the j
        while (i >= 0 && higher_priority(j, i)) {
            swap(i, j);
            j = i;
            i = (i - 1)/2;
        }
    }
};

void dijkstra(int s) {
    // priority_queue<int, vector<int>, Compare> q;
    heap q;
    visited[s] = true;
    best_time[s] = 0;
    q.push(s);

    while (!q.empty()) {
        int u = q.top();
        q.pop();
        for (ride r1: g[u]) {
            if (best_time[u] <= r1.start) {
                if (!visited[r1.stop]) {
                    best_time[r1.stop] = r1.end;
                    visited[r1.stop] = true;
                    q.push(r1.stop);
                } else if (best_time[r1.stop] > r1.end) {
                    best_time[r1.stop] = r1.end;
                    q.increase_priority(r1.stop);
                }
            }
        }
    }
}

// remove repetitions from stops (for example transform 1 1 1 2 to 1 2)
// and return new number of stops
int compress(vector<int>& bs, vector<int>& s) {
    vector<int> bsc;
    vector<int> sc;
    int prev = -1, stops = 0;
    for (int i = 0; i < bs.size(); i++) {
        if (bs[i] != prev) {
            bsc.push_back(bs[i]);
            sc.push_back(s[i]);
            stops++;
            prev = bs[i];
        }
    }
    bs = bsc;
    s = sc;
    return stops;
}

int main() {
    int b;   // number of bus lines 
    int l;   // number of locations bus stops
    cin >> b >> l;

    // fill the graph structure
    g.resize(l);
    int tmp;
    for (int i = 0; i < b; i++) {
        // read stops of the current bus line
        // and count them
        vector<int> bs;
        int stops = 1;
        cin >> tmp;
        while (cin.peek()!='\n') {
            bs.push_back(tmp);
            stops++;
            cin >> tmp;
        }
        bs.push_back(tmp);

        // read at what times the bus stops
        vector<int> s(stops);
        for (int j = 0; j < stops; j++) {
            cin >> s[j];
        }

        // compress bus stops and time
        stops = compress(bs, s);

        // fill the graph
        for (int j = 0; j < bs.size()-1; j++) {
            g[bs[j]].push_back({s[j], s[j+1], bs[j+1]});
        }
    }

    // print the graph
    /*for (int i = 0; i < l; i++) {
        cout << i << ": ";
        for (ride e: g[i]) {
            cout << "(" << e.start << ", " << e.end << ", " << e.stop << "); ";
        }
        cout << endl;
    }*/

    visited.resize(l, false);
    best_time.resize(l, -1);
    dijkstra(0);
    cout << best_time[l-1] << endl;
    return 0;
}

