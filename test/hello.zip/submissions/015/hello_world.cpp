//
// Created by Marten on 13/11/2024.
//

#include <iostream>

int main() {
   std::cout << "Hello world!";
   return 0;
}