#include <iostream>

using namespace std;

int main() {
    cout << "Hello world!";
    return 0;
}