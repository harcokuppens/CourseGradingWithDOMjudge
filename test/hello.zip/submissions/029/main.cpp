#include <iostream>
using namespace std;

int main() {
    int number;

    cin >> number;

    cout << "Hello World!";

    return 0;
}
