#!/bin/bash

SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
cd "$SCRIPT_DIR"
g++ -c main.cpp
g++ -c printer.cpp
g++ main.o printer.o -o hello_cpp
./hello_cpp
rm *.o hello_cpp
