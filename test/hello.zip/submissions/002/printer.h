// printer.h
#ifndef PRINTER_H
#define PRINTER_H

void printMessage();

#endif
