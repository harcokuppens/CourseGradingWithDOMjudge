// printer.cpp
#include <iostream>
#include "printer.h"

void printMessage() {
    std::cout << "Hello world!" << std::endl;
}
