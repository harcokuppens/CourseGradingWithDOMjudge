// main.cpp
#include <iostream>
#include "printer.h"

int main() {
    printMessage();
    return 0;
}
