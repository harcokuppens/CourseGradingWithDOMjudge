from typing import List, Tuple
from enum import Enum
import sys


class NodeType(Enum):
    Arrival = 0
    Departure = 1


class BusLine:
    def __init__(self, stops: List[Tuple[int, int]]):
        """
        stops: [(time_at_stop: int, stop_id: int), ...]
        """
        self.stops = stops


class BusStop:
    def __init__(self, departures: List[Tuple[int, int]]):
        """
        departures: [(departure_time: int, bus_line_id: int), ...]
        """
        self.departures = departures


class Timetable:
    def __init__(self, bus_lines: dict[int, BusLine], stops: dict[int, BusStop], home_stop: int):
        self.bus_lines = bus_lines
        self.stops = stops
        self.home_stop = home_stop
        self.mercator_stop = 0

    @staticmethod
    def from_file(input_str: str):
        """
        Pass the input file into the timetable data format needed for the algorithms
        """
        lines = [[int(i) for i in line.split(" ")] for line in input_str.strip().split("\n")]

        n_bus_lines = lines[0][0]
        n_stops = lines[0][1]
        home_stop = n_stops - 1

        stops = {}
        for id in range(n_stops):
            stops[id] = BusStop([])
        bus_lines = {}
        for line_number in range(n_bus_lines):
            bus_lines[line_number] = BusLine(sorted([
                (departure_time, stop_id)
                for departure_time, stop_id
                in zip(lines[line_number*2+2], lines[line_number*2+1])
            ], key=lambda t: t[0]))

            for departure_time, stop_id in zip(lines[line_number*2+2], lines[line_number*2+1]):
                stops[stop_id].departures.append((departure_time, line_number))

        for stop in stops.values():
            stop.departures = sorted(stop.departures, key=lambda t: t[0])

        return Timetable(bus_lines, stops, home_stop)


def assignment_1(timetable: Timetable, start: int, finish: int) -> Tuple[List[int], List[Tuple[int, int]]]:
    """
    Returns the route with the least total travel time
    """
    queue = [(NodeType.Departure, [], [(0, timetable.mercator_stop)], (0, departure[0], departure[1])) for departure in timetable.stops[timetable.mercator_stop].departures]

    best_route = None
    best_route_time = None

    while len(queue):
        node_type, lines, stops, node = queue.pop(0)

        if node_type == NodeType.Departure:
            transfer_time, departure_time, bus_line_id = node
            if best_route_time is not None and departure_time > best_route_time:
                continue
            for (time_at_stop, stop_id) in timetable.bus_lines[bus_line_id].stops:
                if time_at_stop > departure_time:
                    queue.append((NodeType.Arrival, [*lines, bus_line_id], [*stops], (transfer_time, time_at_stop, stop_id)))

        elif node_type == NodeType.Arrival:
            transfer_time, time_at_stop, stop_id = node
            if best_route_time is not None and time_at_stop > best_route_time:
                continue
            if stop_id == timetable.home_stop and ((best_route_time is not None and best_route_time > time_at_stop) or best_route_time is None):
                best_route_time = time_at_stop
                best_route = (lines, transfer_time, [*stops, (time_at_stop, stop_id)])
            
            for departure_time, bus_line_id in timetable.stops[stop_id].departures:
                added_transfer_time = departure_time - time_at_stop
                if departure_time >= time_at_stop:
                    queue.append((NodeType.Departure, [*lines], [*stops, (time_at_stop, stop_id)], (transfer_time + added_transfer_time, departure_time, bus_line_id)))
        else:
            raise Exception(f"Invalid node_type: {node_type}")

    return best_route


def main() -> int:
    input_str = sys.stdin.read()

    timetable = Timetable.from_file(input_str)

    lines, transfer_time, stops = assignment_1(timetable, timetable.mercator_stop, timetable.home_stop)

    if lines is None or stops is None:
        print("No route found")
    else:
        print("t\tstop")
        print("------------------")
        for idx, (time, stop) in enumerate(stops):
            if idx != 0:
                print(".\t|")
                print(f".\t| bus line {lines[idx - 1]}")
                print(".\t|")
            print(f"{time}\t{stop}")
    
    print(f"\ntotal transfer time: {transfer_time}")

    return 0


if __name__ == "__main__":
    exit(main())
