// Main.kt
fun main() {
    printHelloWorld()
}
