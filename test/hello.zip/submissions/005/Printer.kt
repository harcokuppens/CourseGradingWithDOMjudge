// Printer.kt
fun printHelloWorld() {
    println("Hello world!")
}
