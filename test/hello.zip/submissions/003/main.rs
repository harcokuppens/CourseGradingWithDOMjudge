// main.rs
mod printer;

fn main() {
    printer::print_message();
}
