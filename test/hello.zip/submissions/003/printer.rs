// printer.rs
pub fn print_message() {
    println!("Hello world!");
}
