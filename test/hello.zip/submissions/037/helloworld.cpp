#include <iostream>
using namespace std;

void printHello(...){

    cout << "Hello World!" << endl;

}


int main() {
    printHello(1);
}
