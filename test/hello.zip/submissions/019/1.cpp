#include <iostream>
#include <vector>
#include <map>
#include <queue>
#include <string>
#include <set>
using namespace std;

struct BusStop {
    string location;
    int time;
    int busLine;
};

struct Edge {
    int destinationStop;
    int waitingTime;
    int busLine;
};

map<int, vector<Edge>> buildGraph(const vector<vector<BusStop>>& schedule, set<int>& homeTimes) {
    map<int, vector<Edge>> graph;
    for (const auto& bus : schedule) {
        for (size_t i = 0; i < bus.size() - 1; i++) {
            int currentStop = bus[i].time;
            int nextStop = bus[i + 1].time;
            int waitingTime = bus[i + 1].time - bus[i].time;

            graph[currentStop].push_back({nextStop, waitingTime, bus[i + 1].busLine});

            if (bus[i + 1].location == "Home") {
                homeTimes.insert(nextStop);
            }
        }
    }
    return graph;
}

int findMaximalWaitingTime(const vector<vector<BusStop>>& schedule, const string& start, const string& destination) {
    set<int> homeTimes;
    auto graph = buildGraph(schedule, homeTimes);

    map<int, int> maxWaitingTime;
    priority_queue<pair<int, int>> pq;

    pq.push({0, 0}); 
    maxWaitingTime[0] = 0;

    while (!pq.empty()) {
        auto [currentWaitingTime, currentStop] = pq.top();
        pq.pop();
        currentWaitingTime = -currentWaitingTime;

        if (maxWaitingTime[currentStop] > currentWaitingTime) continue;

        for (const auto& edge : graph[currentStop]) {
            int newWaitingTime = currentWaitingTime + edge.waitingTime;
            if (newWaitingTime > maxWaitingTime[edge.destinationStop]) {
                maxWaitingTime[edge.destinationStop] = newWaitingTime;
                pq.push({-newWaitingTime, edge.destinationStop});
            }
        }
    }

    int result = -1;
    for (int homeTime : homeTimes) {
        if (maxWaitingTime.find(homeTime) != maxWaitingTime.end()) {
            result = max(result, maxWaitingTime[homeTime]);
        }
    }
    
    return result;
}

int main() {
    vector<vector<BusStop>> schedule = {
        {{ "Mercator", 0, 0 }, { "Spookuil", 5, 0 }, { "Central Station", 10, 0 }, { "Waalkade", 15, 0 }},
        {{ "Waalkade", 10, 1 }, { "Central Station", 20, 1 }, { "Spookuil", 50, 1 }, { "Home", 60, 1 }},
        {{ "Central Station", 15, 2 }, { "Home", 17, 2 }, { "Waalkade", 20, 2 }, { "Spookuil", 25, 2 }},
        {{ "Spookuil", 6, 3 }, { "Waalkade", 9, 3 }, { "Home", 25, 3 }, { "Central Station", 35, 3 }}
    };

    int maximalWaitingTime = findMaximalWaitingTime(schedule, "Mercator", "Home");
    cout << "The maximal waiting time to reach Home is: " << maximalWaitingTime << " minutes\n";

    return 0;
}
