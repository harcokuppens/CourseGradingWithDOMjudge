import sys

n = int(input())
if(n == 1):
    print("Hello world!")