#include <iostream>

using namespace std;


int main() {
    string line;
    getline(cin,line);
    cout << "Hello World!";
    return 0;
}

