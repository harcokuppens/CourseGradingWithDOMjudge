#!/bin/bash

SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
cd "$SCRIPT_DIR"
gcc -c main.c
gcc -c printer.c
gcc main.o printer.o -o hello_c
./hello_c
rm *.o hello_c
