// printer.h
#ifndef PRINTER_H
#define PRINTER_H

void print_message();

#endif
