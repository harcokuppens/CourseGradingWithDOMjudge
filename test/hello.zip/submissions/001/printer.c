// printer.c
#include <stdio.h>
#include "printer.h"

void print_message() {
    printf("Hello world!\n");
}
