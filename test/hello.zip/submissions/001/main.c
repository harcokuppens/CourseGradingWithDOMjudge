// main.c
#include <stdio.h>
#include "printer.h"

int main() {
    print_message();
    return 0;
}
