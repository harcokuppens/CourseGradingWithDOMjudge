import heapq


def solve(input_data):
    lines = input_data.strip().split('\n')

    # Read B and L
    B, L = map(int, lines[0].split())

    # Adjacency list representing the search space.
    stops = {i: [] for i in range(L)}

    for i in range(B):
        line_stops = list(map(int, lines[1 + i * 2].split()))
        line_times = list(map(int, lines[2 + i * 2].split()))

        # Populate list with connections and travel times.
        for j in range(1, len(line_stops)):
            current_stop = line_stops[j]
            previous_stop = line_stops[j - 1]

            # Append the departure time at the previous bus stop, current arrival time and destination bus stop.
            stops[previous_stop].append((line_times[j - 1], line_times[j], current_stop))

    return min_travel_time(L, stops)


def min_travel_time(L, stops):
    # Priority queue for Dijkstra to store (current_time, current_stop).
    pq = []
    heapq.heappush(pq, (0, 0))  # Start from Mercator at 12 'o clock

    # Keep track of the shortest time to each stop.
    min_time = [float('inf')] * L
    min_time[0] = 0
    while pq:
        current_time, current_stop = heapq.heappop(pq)

        # If we reach the destination return the time.
        if current_stop == L - 1:
            return current_time

        # Iterate through connected stops.
        for depart_time, arrive_time, next_stop in stops[current_stop]:
            # Check if the bus departs after the current time and if we can reach next_stop faster.
            if current_time <= depart_time and arrive_time < min_time[next_stop]:
                min_time[next_stop] = arrive_time
                heapq.heappush(pq, (arrive_time, next_stop))

    return -1  # no valid path to the last stop.


def main():
    input_lines = []
    try:
        while True:
            line = input()
            input_lines.append(line)
    except EOFError:
        input_data = '\n'.join(input_lines)

    result = solve(input_data)
    print(result)


if __name__ == "__main__":
    main()
