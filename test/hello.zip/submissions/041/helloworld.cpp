#include <iostream>
#include <string>

using namespace std;

int main() {
    string input;
    getline(cin,input);
    cout<<"Hello world!";
    return 0; 
}
