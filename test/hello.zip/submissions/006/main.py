# main.py
from printer import print_message

if __name__ == "__main__":
    print_message()
