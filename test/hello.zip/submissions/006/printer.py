# printer.py
def print_message():
    print("Hello world!")
