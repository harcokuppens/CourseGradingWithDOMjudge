import heapq
import time

def minimal(bus_graph, locations1):
    graph = {i: [] for i in range(locations1)}
    for locations2, times in bus_graph:
        for i in range(len(locations2) - 1):
            graph[locations2[i]].append((locations2[i+1], times[i+1]))
    
    start = 0
    end = locations1 - 1
    min_time = [float('inf')] * locations1
    min_time[start] = 0
    priority_que = [(0, start)]
    
    while priority_que:
        current_time, current_location = heapq.heappop(priority_que)
        if current_time > min_time[current_location]:
            continue
        for next_location, next_time in graph[current_location]:
            if next_time < min_time[next_location]:
                min_time[next_location] = next_time
                heapq.heappush(priority_que, (next_time, next_location))
    
    return min_time[end] if min_time[end] != float('inf') else -1

def read_input_from_console():
    # Read the number of buses and locations
    B, L = map(int, input().strip().split())
    bus_graph = []
    
    for _ in range(B):
        # print(f"Enter stops for bus {_}:")
        locations = list(map(int, input().strip().split()))
        # print(f"Enter times for bus {_}:")
        times = list(map(int, input().strip().split()))
        bus_graph.append((locations, times))
    
    return bus_graph, L

if __name__ == "__main__":
    # Measure running time
    # start_time = time.time()
    
    # Read input from console
    bus_graph, locations1 = read_input_from_console()
    result = minimal(bus_graph, locations1)
    
    # end_time = time.time()
    
    print(result)
    # print(f"Execution time: {end_time - start_time:.4f} seconds")
