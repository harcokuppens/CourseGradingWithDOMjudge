bruh = input()
print(bruh)