input()
print('Hello world!')