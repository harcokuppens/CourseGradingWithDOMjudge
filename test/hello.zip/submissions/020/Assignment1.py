# -*- coding: utf-8 -*-
"""
Created on Tue Nov 12 14:11:20 2024

@author: Asus
"""
bus_schedule = {
    0: [("Mercator", 0), ("Spoorkuil", 5), ("Central Station", 10), ("Waalkade", 15)],
    1: [("Waalkade", 10), ("Central Station", 20), ("Spoorkuil", 50), ("Home", 60)],
    2: [("Central Station", 15), ("Home", 17), ("Waalkade", 20), ("Spoorkuil", 25)],
    3: [("Spoorkuil", 6), ("Waalkade", 9), ("Home", 25), ("Central Station", 35)]
}

# Function to find the minimal arrival time at a target location
def find_min_time(start_location, target_location):
    minimal_times = {}
    minimal_times[start_location] = 0
    target_reached = False
    arrival_time = None
    while not target_reached:
        updated = False      
        for bus, stops in bus_schedule.items():
            for location, time in stops:
                if location not in minimal_times or minimal_times[location] > time:
                    minimal_times[location] = time
                    updated = True
                    if location == target_location:
                        target_reached = True
                        if arrival_time is None or time < arrival_time:
                            arrival_time = time
        if not updated:
            break
    
    return arrival_time

# Example usage: find the minimal arrival time to "Home" starting from "Mercator" at time 0
start_location = "Mercator"
target_location = "Waalkade"

minimal_time = find_min_time(start_location, target_location)
print(minimal_time)
