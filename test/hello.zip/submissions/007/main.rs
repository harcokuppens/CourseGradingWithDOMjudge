mod foo;

fn main() {
    foo::hello();
}
